<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2010-11-07 11:27:20 --> Severity: 8192  --> Assigning the return value of new by reference is deprecated /var/www/fitness/system/application/libraries/Loader.php 414
ERROR - 2010-11-07 11:27:20 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2010-11-07 11:59:38 --> Severity: Warning  --> include_once(Fitness_Admin_controller.php): failed to open stream: No such file or directory /var/www/fitness/system/application/libraries/MY_Controller.php 75
ERROR - 2010-11-07 11:59:38 --> Severity: Warning  --> include_once(): Failed opening 'Fitness_Admin_controller.php' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/fitness/system/application/libraries/MY_Controller.php 75
ERROR - 2010-11-07 11:59:46 --> Severity: Warning  --> include_once(Fitness_Admin_controller.php): failed to open stream: No such file or directory /var/www/fitness/system/application/libraries/MY_Controller.php 75
ERROR - 2010-11-07 11:59:46 --> Severity: Warning  --> include_once(): Failed opening 'Fitness_Admin_controller.php' for inclusion (include_path='.:/usr/share/php:/usr/share/pear') /var/www/fitness/system/application/libraries/MY_Controller.php 75
ERROR - 2010-11-07 12:01:41 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 12:01:41 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 12:02:22 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 12:02:22 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 12:03:45 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 12:03:46 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 12:03:46 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 12:03:46 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 12:03:46 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 12:03:49 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 12:03:49 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 12:03:51 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 12:03:51 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 12:03:52 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 12:03:52 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 12:03:52 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 12:03:52 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 12:03:52 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 12:25:26 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'c3websiteclub'@'localhost' (using password: YES) /var/www/fitness/system/database/drivers/mysql/mysql_driver.php 88
ERROR - 2010-11-07 12:25:26 --> Unable to connect to the database
ERROR - 2010-11-07 12:25:32 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'c3websiteclub'@'localhost' (using password: YES) /var/www/fitness/system/database/drivers/mysql/mysql_driver.php 88
ERROR - 2010-11-07 12:25:32 --> Unable to connect to the database
ERROR - 2010-11-07 12:25:33 --> Severity: Warning  --> mysql_pconnect(): Access denied for user 'c3websiteclub'@'localhost' (using password: YES) /var/www/fitness/system/database/drivers/mysql/mysql_driver.php 88
ERROR - 2010-11-07 12:25:33 --> Unable to connect to the database
ERROR - 2010-11-07 12:25:55 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 12:25:56 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 12:25:56 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 12:25:56 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 12:25:56 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 12:25:58 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 12:25:58 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 12:25:59 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 12:26:00 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 12:26:00 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 12:26:00 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 12:26:00 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 12:26:02 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 12:26:02 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 12:34:00 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2010-11-07 12:34:52 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2010-11-07 13:09:30 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2010-11-07 13:10:11 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:10:11 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:10:13 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:10:13 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:10:14 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 13:10:15 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 13:10:15 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:10:15 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 13:10:15 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:14:17 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:14:17 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:14:20 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:14:20 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:14:20 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 13:14:21 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 13:14:21 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:14:21 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 13:14:21 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:14:23 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:14:23 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:16:29 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:16:29 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:16:35 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:16:35 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:18:21 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:18:21 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:18:23 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:18:23 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:18:25 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 13:18:26 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 13:18:26 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:18:26 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 13:18:26 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:49:09 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2010-11-07 13:49:21 --> Query error: Table 'fitness.be_acl_groups' doesn't exist
ERROR - 2010-11-07 13:51:59 --> Query error: Table 'fitness.omc_week' doesn't exist
ERROR - 2010-11-07 13:53:10 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:53:10 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:53:12 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:53:13 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:53:14 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 13:53:15 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 13:53:15 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:53:15 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 13:53:15 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:53:17 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:53:17 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:53:23 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:53:23 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:53:35 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:53:35 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:53:48 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:53:48 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:54:04 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:54:04 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:54:59 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:54:59 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:55:57 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:55:57 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:55:58 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 13:55:59 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 13:55:59 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 13:55:59 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 13:55:59 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:56:02 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 13:56:02 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 14:07:55 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2010-11-07 14:08:06 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 14:08:06 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 14:08:07 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 14:08:07 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 14:08:08 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 14:08:08 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 14:08:08 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 14:08:08 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 14:08:08 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 14:08:11 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 14:08:11 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 15:25:24 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 15:25:24 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 15:25:32 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 15:25:32 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 15:46:21 --> The session cookie data did not match what was expected. This could be a possible hacking attempt.
ERROR - 2010-11-07 16:22:21 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 16:22:21 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 16:22:22 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 16:22:22 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 16:22:38 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 16:22:38 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 16:22:40 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
ERROR - 2010-11-07 16:22:40 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 16:22:41 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 16:22:42 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 16:22:42 --> 404 Page Not Found --> admin/AjaxgetShoutBox
ERROR - 2010-11-07 16:22:42 --> BackendPro->BeP_Site->set_crumb : When setting a breadcrumb a name must be given
ERROR - 2010-11-07 16:22:42 --> 404 Page Not Found --> admin/AjaxgetCompletedBox
