<div id="footer">
		
		<div id="copyright"><!-- START COPYRIGHT -->
		Copyright &copy; 2010 My company name. All rights reserved.
		
		</div><!-- END COPYRIGHT -->
	</div><!-- END of FOOTER  -->
    