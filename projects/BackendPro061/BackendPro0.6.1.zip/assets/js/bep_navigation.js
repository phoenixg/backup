/* Script to provide the navigation menu with functionality */
$(document).ready(function(){
    $('#menu').treeview({
        cookie_name: 'bep_navigation'
    }); 
});